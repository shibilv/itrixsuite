import { access, mkdir, stat } from 'node:fs/promises';
import { constants } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const checks = [];

async function checkFile(label, path) {
  const fullPath = resolve(root, path);
  try {
    const info = await stat(fullPath);
    checks.push({ label, ok: info.isFile(), detail: fullPath });
  } catch (error) {
    checks.push({ label, ok: false, detail: `${fullPath} (${error.message})` });
  }
}

async function checkWritableDir(label, path) {
  const fullPath = resolve(root, path);
  try {
    await mkdir(fullPath, { recursive: true });
    await access(fullPath, constants.R_OK | constants.W_OK);
    checks.push({ label, ok: true, detail: fullPath });
  } catch (error) {
    checks.push({ label, ok: false, detail: `${fullPath} (${error.message})` });
  }
}

await checkFile('Legacy server', 'legacy-app/serve-login.mjs');
await checkFile('Package file', 'package.json');
await checkFile('PM2 config', 'ecosystem.config.cjs');
await checkWritableDir('Saved job receipts folder', 'saved-job-receipts');
await checkWritableDir('Survival backup folder', 'survival-backups');
await checkWritableDir('Database backup folder', 'legacy-app/backups');

const requiredEnv = ['NODE_ENV', 'HOST', 'PORT', 'ITRIX_DB_NAME', 'ITRIX_DB_CLIENT', 'ITRIX_DB_DUMP_CLIENT'];
for (const key of requiredEnv) {
  checks.push({ label: `ENV ${key}`, ok: Boolean(process.env[key]), detail: process.env[key] ? 'set' : 'not set' });
}

const hasTcpDb = Boolean(process.env.ITRIX_DB_HOST && process.env.ITRIX_DB_USER);
const hasSocketDb = Boolean(process.env.ITRIX_DB_SOCKET);
checks.push({
  label: 'Database connection mode',
  ok: hasTcpDb || hasSocketDb,
  detail: hasTcpDb ? 'TCP host/user configured' : hasSocketDb ? 'Socket configured' : 'set ITRIX_DB_HOST + ITRIX_DB_USER, or ITRIX_DB_SOCKET',
});

for (const check of checks) {
  console.log(`${check.ok ? '✓' : '✗'} ${check.label}: ${check.detail}`);
}

const failed = checks.filter((check) => !check.ok);
if (failed.length) {
  console.error(`\n${failed.length} preflight check(s) need attention before hosting.`);
  process.exit(1);
}

console.log('\nHosting preflight checks passed.');
