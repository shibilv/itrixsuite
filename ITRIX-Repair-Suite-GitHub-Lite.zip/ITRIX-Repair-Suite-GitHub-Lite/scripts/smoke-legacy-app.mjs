#!/usr/bin/env node
import http from 'node:http';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const rootDir = resolve(__dirname, '..');
const legacyDir = resolve(rootDir, 'legacy-app');
const baseUrl = process.env.LEGACY_APP_URL || 'http://127.0.0.1:8080';
const adminUser = process.env.LEGACY_SMOKE_USER || 'admin';
const optionalJobId = process.env.LEGACY_SMOKE_JOB_ID || '';
const optionalCustomerId = process.env.LEGACY_SMOKE_CUSTOMER_ID || '';

const requiredRoutes = [
  {
    path: '/welcome/index',
    name: 'Login page',
    auth: false,
    mustContain: ['ITRIX Service Login', 'Staff Access'],
  },
  {
    path: '/welcome/home',
    name: 'Dashboard',
    auth: true,
    mustContain: ['Operations Dashboard', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/settings',
    name: 'Settings',
    auth: true,
    mustContain: ['Admin Settings', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/audit-log',
    name: 'Audit Log',
    auth: true,
    mustContain: ['Audit Log', 'settings-sidebar-toggle', '--itx-bg'],
    anyContain: ['settings-sidebar-toggle', 'has-treeview'],
  },
  {
    path: '/welcome/staff-performance',
    name: 'Staff Performance',
    auth: true,
    mustContain: ['Staff Performance', 'Staff-wise Summary', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/system-health',
    name: 'System Health',
    auth: true,
    mustContain: ['System Health', 'Safety Checks', 'Storage Usage', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/staff-payroll',
    name: 'Attendance / Payroll',
    auth: true,
    mustContain: ['Attendance & Payroll', 'Self attendance', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/search-jobs?q=333',
    name: 'Search Jobs',
    auth: true,
    mustContain: ['Search Jobs', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/add-new-job',
    name: 'Add New Job',
    auth: true,
    mustContain: ['Add New Job', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/jobs',
    name: 'Jobs Report',
    auth: true,
    mustContain: ['Jobs', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/add-invoice',
    name: 'Add Invoice',
    auth: true,
    mustContain: ['Add Invoice', 'Invoice-ready Jobs', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/invoice-search',
    name: 'Invoice Search',
    auth: true,
    mustContain: ['Invoice Search', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/receipt-search',
    name: 'Receipt Search',
    auth: true,
    mustContain: ['Receipt Search', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/add-receipt',
    name: 'Add Receipt',
    auth: true,
    mustContain: ['Add Receipt', 'settings-sidebar-toggle', '--itx-bg'],
  },
  {
    path: '/welcome/daily-closing',
    name: 'Daily Closing',
    auth: true,
    mustContain: ['Daily Closing', 'settings-sidebar-toggle', '--itx-bg'],
  },
];

if (optionalCustomerId) {
  requiredRoutes.push({
    path: `/welcome/customer/${encodeURIComponent(optionalCustomerId)}/ledger`,
    name: `Customer Ledger ${optionalCustomerId}`,
    auth: true,
    mustContain: ['Ledger Statement', 'settings-sidebar-toggle', '--itx-bg'],
  });
}

if (optionalJobId) {
  requiredRoutes.push(
    {
      path: `/welcome/job/${encodeURIComponent(optionalJobId)}`,
      name: `Job ${optionalJobId}`,
      auth: true,
      mustContain: [`Job #${optionalJobId}`, 'Update Job Status'],
    },
    {
      path: `/welcome/job/${encodeURIComponent(optionalJobId)}/invoice`,
      name: `Invoice Job ${optionalJobId}`,
      auth: true,
      mustContain: [`Invoice for Job #${optionalJobId}`],
    },
  );
}

const badPatterns = [
  /ReferenceError/i,
  /TypeError/i,
  /SyntaxError/i,
  /SQL syntax/i,
  /UnhandledPromiseRejection/i,
  /Cannot GET/i,
  /ENOENT/i,
];

function request(path, { auth = true } = {}) {
  return new Promise((resolveRequest, rejectRequest) => {
    const url = new URL(path, baseUrl);
    const req = http.request(url, {
      method: 'GET',
      timeout: 15000,
      headers: auth ? { Cookie: `itrix_user=${encodeURIComponent(adminUser)}` } : {},
    }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => {
        body += chunk;
      });
      res.on('end', () => resolveRequest({
        statusCode: res.statusCode || 0,
        headers: res.headers,
        body,
      }));
    });
    req.on('timeout', () => {
      req.destroy(new Error(`Timed out loading ${path}`));
    });
    req.on('error', rejectRequest);
    req.end();
  });
}

async function isServerRunning() {
  try {
    const response = await request('/welcome/index', { auth: false });
    return response.statusCode >= 200 && response.statusCode < 500;
  } catch {
    return false;
  }
}

async function waitForServer() {
  const startedAt = Date.now();
  while (Date.now() - startedAt < 20000) {
    if (await isServerRunning()) return true;
    await new Promise((resolveTimer) => setTimeout(resolveTimer, 500));
  }
  return false;
}

async function startServerIfNeeded() {
  if (await isServerRunning()) return null;
  const child = spawn(process.execPath, ['serve-login.mjs'], {
    cwd: legacyDir,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.on('data', (data) => process.stdout.write(`[server] ${data}`));
  child.stderr.on('data', (data) => process.stderr.write(`[server] ${data}`));
  const ready = await waitForServer();
  if (!ready) {
    child.kill('SIGTERM');
    throw new Error('Legacy app server did not start within 20 seconds.');
  }
  return child;
}

function checkRoute(route, response) {
  const failures = [];
  if (![200, 302].includes(response.statusCode)) {
    failures.push(`Expected HTTP 200/302, got ${response.statusCode}`);
  }
  if (response.statusCode === 302) {
    const location = response.headers.location || '';
    failures.push(`Unexpected redirect to ${location}`);
  }
  if (!response.body || response.body.length < 200) {
    failures.push(`Response body is too small (${response.body?.length || 0} chars)`);
  }
  for (const pattern of badPatterns) {
    if (pattern.test(response.body)) failures.push(`Found error pattern: ${pattern}`);
  }
  for (const marker of route.mustContain || []) {
    if (!response.body.includes(marker)) failures.push(`Missing marker: ${marker}`);
  }
  if (route.anyContain?.length && !route.anyContain.some((marker) => response.body.includes(marker))) {
    failures.push(`Missing any marker: ${route.anyContain.join(' OR ')}`);
  }
  return failures;
}

async function main() {
  const ownedServer = await startServerIfNeeded();
  const failures = [];
  try {
    for (const route of requiredRoutes) {
      const response = await request(route.path, { auth: route.auth });
      const routeFailures = checkRoute(route, response);
      if (routeFailures.length) {
        failures.push({ route, routeFailures });
        console.error(`✗ ${route.name} ${route.path}`);
        for (const failure of routeFailures) console.error(`  - ${failure}`);
      } else {
        console.log(`✓ ${route.name} ${route.path}`);
      }
    }
  } finally {
    if (ownedServer) ownedServer.kill('SIGTERM');
  }

  if (failures.length) {
    console.error(`\n${failures.length} smoke-test route(s) failed.`);
    process.exitCode = 1;
    return;
  }
  console.log('\nLegacy app smoke test passed.');
}

main().catch((error) => {
  console.error(error.stack || error.message || error);
  process.exitCode = 1;
});
