<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ITRIX Service Login</title>

  <link rel="stylesheet" href="<?php echo base_url() ?>plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>dist/css/adminlte.min.css">
  <style>
    :root {
      --itrix-blue: #155bd5;
      --itrix-red: #e4042f;
      --itrix-ink: #172033;
      --itrix-muted: #6b7280;
      --itrix-line: #e6ebf2;
      --itrix-bg: #f4f7fb;
    }

    * {
      box-sizing: border-box;
    }

    body.itrix-login-page {
      min-height: 100vh;
      margin: 0;
      background:
        radial-gradient(circle at 12% 10%, rgba(21, 91, 213, .15), transparent 32%),
        radial-gradient(circle at 88% 16%, rgba(228, 4, 47, .10), transparent 30%),
        linear-gradient(135deg, #eef4ff 0%, #f8fafc 48%, #fff5f7 100%);
      color: var(--itrix-ink);
      font-family: "Source Sans Pro", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      overflow-x: hidden;
    }

    .itrix-login-shell {
      width: min(1080px, calc(100% - 28px));
      min-height: 100vh;
      margin: 0 auto;
      display: grid;
      grid-template-columns: minmax(0, 1.05fr) 430px;
      align-items: center;
      gap: 34px;
      padding: 34px 0;
      position: relative;
    }

    .itrix-login-shell::before,
    .itrix-login-shell::after {
      content: "";
      position: absolute;
      border-radius: 999px;
      pointer-events: none;
    }

    .itrix-login-shell::before {
      width: 190px;
      height: 190px;
      right: -78px;
      top: 58px;
      background: rgba(21, 91, 213, .09);
    }

    .itrix-login-shell::after {
      width: 120px;
      height: 120px;
      left: -52px;
      bottom: 76px;
      background: rgba(228, 4, 47, .08);
    }

    .itrix-login-hero,
    .itrix-login-card {
      position: relative;
      z-index: 1;
    }

    .itrix-login-hero {
      padding: 24px;
    }

    .itrix-logo-panel {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 18px 22px;
      border: 1px solid rgba(255,255,255,.85);
      border-radius: 28px;
      background: rgba(255,255,255,.9);
      box-shadow: 0 12px 28px rgba(15, 23, 42, .07);
      margin-bottom: 26px;
    }

    .itrix-logo-panel img {
      width: min(360px, 72vw);
      height: auto;
      display: block;
    }

    .itrix-login-hero h1 {
      font-size: clamp(34px, 5vw, 58px);
      line-height: 1;
      font-weight: 900;
      letter-spacing: -.04em;
      margin: 0 0 14px;
      color: #0f172a;
    }

    .itrix-login-hero p {
      max-width: 560px;
      margin: 0 0 24px;
      font-size: 18px;
      line-height: 1.55;
      color: var(--itrix-muted);
    }

    .itrix-login-points {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 12px;
      max-width: 620px;
    }

    .itrix-point {
      border: 1px solid rgba(226, 232, 240, .9);
      border-radius: 18px;
      background: rgba(255,255,255,.64);
      padding: 14px;
      box-shadow: 0 10px 30px rgba(15, 23, 42, .05);
    }

    .itrix-point i {
      width: 34px;
      height: 34px;
      border-radius: 12px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background: rgba(21, 91, 213, .10);
      color: var(--itrix-blue);
      margin-bottom: 10px;
    }

    .itrix-point strong {
      display: block;
      font-size: 14px;
      color: #111827;
      line-height: 1.2;
    }

    .itrix-login-card {
      border: 1px solid rgba(255,255,255,.88);
      border-radius: 30px;
      background: rgba(255,255,255,.96);
      box-shadow: 0 18px 44px rgba(15, 23, 42, .12);
      overflow: hidden;
    }

    .itrix-login-card-header {
      padding: 28px 30px 10px;
      text-align: left;
    }

    .itrix-login-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      border-radius: 999px;
      background: #eef5ff;
      color: var(--itrix-blue);
      font-weight: 800;
      font-size: 12px;
      letter-spacing: .04em;
      text-transform: uppercase;
      margin-bottom: 18px;
    }

    .itrix-login-card h2 {
      margin: 0 0 7px;
      font-size: 28px;
      font-weight: 900;
      letter-spacing: -.025em;
      color: #111827;
    }

    .itrix-login-card p {
      margin: 0;
      color: var(--itrix-muted);
      font-size: 15px;
    }

    .itrix-login-form {
      padding: 22px 30px 30px;
    }

    .itrix-field {
      margin-bottom: 16px;
    }

    .itrix-field label {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 7px;
      font-size: 13px;
      font-weight: 800;
      color: #263244;
    }

    .itrix-input-wrap {
      position: relative;
    }

    .itrix-input-wrap i {
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: #8a97a8;
      pointer-events: none;
    }

    .itrix-input-wrap .form-control {
      height: 52px;
      border: 1px solid var(--itrix-line);
      border-radius: 16px;
      padding-left: 44px;
      padding-right: 16px;
      background: #f9fbff;
      color: #111827;
      font-size: 16px;
      transition: border-color .18s ease, box-shadow .18s ease, background-color .18s ease;
    }

    .itrix-input-wrap .form-control:focus {
      border-color: rgba(21, 91, 213, .62);
      background: #fff;
      box-shadow: 0 0 0 4px rgba(21, 91, 213, .10);
    }

    .itrix-login-error {
      display: block;
      min-height: 18px;
      margin-top: 6px;
      color: var(--itrix-red);
      font-size: 13px;
      font-weight: 700;
    }

    .itrix-login-actions {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin: 4px 0 20px;
      color: var(--itrix-muted);
      font-size: 13px;
    }

    .itrix-login-actions span {
      display: inline-flex;
      align-items: center;
      gap: 7px;
    }

    .itrix-login-button {
      width: 100%;
      height: 52px;
      border: 0;
      border-radius: 16px;
      background: linear-gradient(135deg, var(--itrix-blue), #0f46b3);
      box-shadow: 0 14px 28px rgba(21, 91, 213, .24);
      color: #fff;
      font-size: 16px;
      font-weight: 900;
      letter-spacing: .01em;
      transition: transform .15s ease, box-shadow .15s ease, filter .15s ease;
    }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation-duration: .001ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: .001ms !important;
        scroll-behavior: auto !important;
      }
    }

    .itrix-login-button:hover {
      color: #fff;
      transform: translateY(-1px);
      box-shadow: 0 18px 34px rgba(21, 91, 213, .30);
      filter: brightness(1.02);
    }

    .itrix-login-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-top: 20px;
      padding-top: 18px;
      border-top: 1px solid var(--itrix-line);
      color: var(--itrix-muted);
      font-size: 13px;
    }

    .itrix-login-footer strong {
      color: #111827;
    }

    @media (max-width: 900px) {
      .itrix-login-shell {
        grid-template-columns: 1fr;
        gap: 18px;
        padding: 22px 0;
      }

      .itrix-login-hero {
        text-align: center;
        padding: 10px 8px 0;
      }

      .itrix-login-hero p {
        margin-left: auto;
        margin-right: auto;
      }

      .itrix-login-points {
        grid-template-columns: 1fr;
        max-width: 430px;
        margin: 0 auto;
      }
    }

    @media (max-width: 480px) {
      .itrix-login-shell {
        width: min(100% - 18px, 430px);
      }

      .itrix-login-hero h1 {
        font-size: 32px;
      }

      .itrix-login-hero p,
      .itrix-login-points {
        display: none;
      }

      .itrix-logo-panel {
        padding: 12px 15px;
        border-radius: 22px;
        margin-bottom: 10px;
      }

      .itrix-login-card {
        border-radius: 24px;
      }

      .itrix-login-card-header,
      .itrix-login-form {
        padding-left: 20px;
        padding-right: 20px;
      }

      .itrix-login-footer {
        align-items: flex-start;
        flex-direction: column;
      }
    }
  </style>
</head>
<body class="hold-transition itrix-login-page">
  <main class="itrix-login-shell">
    <section class="itrix-login-hero" aria-label="ITRIX service overview">
      <div class="itrix-logo-panel">
        <img src="<?php echo base_url() ?>plugins/assets/img/itrix-receipt-logo.png" alt="ITRIX Service">
      </div>
      <h1>Repair operations made simple.</h1>
      <p>Secure staff login for job intake, service timeline, invoices, receipts, customer ledger and delivery tracking.</p>
      <div class="itrix-login-points">
        <div class="itrix-point"><i class="fas fa-briefcase"></i><strong>Track jobs clearly</strong></div>
        <div class="itrix-point"><i class="fas fa-user-shield"></i><strong>Staff permissions</strong></div>
        <div class="itrix-point"><i class="fas fa-receipt"></i><strong>Billing & ledger</strong></div>
      </div>
    </section>

    <section class="itrix-login-card" aria-label="Staff login">
      <div class="itrix-login-card-header">
        <div class="itrix-login-badge"><i class="fas fa-lock"></i> Staff Access</div>
        <h2>Welcome back</h2>
        <p>Sign in to continue to the ITRIX dashboard.</p>
      </div>

      <form class="itrix-login-form" method="post" action="<?php echo base_url() ?>welcome/login" autocomplete="off">
        <div class="itrix-field">
          <label for="username">Username / Phone</label>
          <div class="itrix-input-wrap">
            <i class="fas fa-user"></i>
            <input type="text" class="form-control" name="name" id="username" placeholder="Enter staff username" autocomplete="username" autofocus>
          </div>
          <span class="itrix-login-error"><?php echo isset($uerror) ? $uerror : ''; ?></span>
        </div>

        <div class="itrix-field">
          <label for="password">Password</label>
          <div class="itrix-input-wrap">
            <i class="fas fa-key"></i>
            <input type="password" class="form-control" name="password" id="password" placeholder="Enter password" autocomplete="current-password">
          </div>
          <span class="itrix-login-error"><?php echo isset($perror) ? $perror : ''; ?></span>
        </div>

        <div class="itrix-login-actions">
          <span><i class="fas fa-shield-alt"></i> Protected local access</span>
          <span>ITRIX Service</span>
        </div>

        <button type="submit" class="btn itrix-login-button">
          Login to Dashboard <i class="fas fa-arrow-right ml-2"></i>
        </button>

        <div class="itrix-login-footer">
          <span><strong>ITRIX SERVICE</strong><br>Talap, Kannur-2</span>
          <span><i class="fas fa-phone-alt mr-1"></i>0497-7963626</span>
        </div>
      </form>
    </section>
  </main>

  <script src="<?php echo base_url() ?>plugins/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url() ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url() ?>dist/js/adminlte.min.js"></script>
</body>
</html>
