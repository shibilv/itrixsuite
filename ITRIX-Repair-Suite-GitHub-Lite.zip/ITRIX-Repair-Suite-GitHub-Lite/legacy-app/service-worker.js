const ITRIX_CACHE = 'itrix-repair-suite-v1';
const STATIC_ASSETS = [
  '/plugins/fontawesome-free/css/all.min.css',
  '/plugins/bootstrap/js/bootstrap.bundle.min.js',
  '/plugins/jquery/jquery.min.js',
  '/dist/css/adminlte.min.css',
  '/dist/js/adminlte.min.js',
  '/dist/img/itrix-logo-only.jpg',
  '/plugins/assets/img/apple-touch-icon.png',
  '/plugins/assets/img/favicon.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(ITRIX_CACHE)
      .then((cache) => cache.addAll(STATIC_ASSETS))
      .catch(() => undefined)
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== ITRIX_CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  const isStatic = STATIC_ASSETS.includes(url.pathname) || url.pathname.startsWith('/plugins/') || url.pathname.startsWith('/dist/');
  if (!isStatic) return;

  event.respondWith(
    caches.match(request).then((cached) => cached || fetch(request).then((response) => {
      const copy = response.clone();
      caches.open(ITRIX_CACHE).then((cache) => cache.put(request, copy)).catch(() => undefined);
      return response;
    }))
  );
});
